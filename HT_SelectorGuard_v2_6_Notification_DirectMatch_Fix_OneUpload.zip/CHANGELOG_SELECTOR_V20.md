# v2.0 变更与第三分钟防漏设计

- 新全场独立筛选 `app/src/main/assets/fulltime_engine.js`；主队占优、低进球，三张固定比分单及赔率覆盖；与半场模型分离
- 筛选页 HT/FT 切换，已选择比赛保存独立模式，手机与手表自动显示
- `MatchLifecycle`: 全场 HT 暂停而不清除，下半场继续；FT 才清理
- `MonitorService`: 60/75/85 全场辅助节点，第二半场重建时间窗口
- `AlertPolicy.selectorMinuteThreeFresh`: 仅接受最新真实 1H 赛事分钟 >=3
- `AlertNotifier.postSelectorStart`: 第3分钟独立开始确认，每场去重；延迟时写明实际分钟
- Watch8 原通知通道照常派送，新增 3′ 启动标签，不改旧进球/红牌/守分格式
- `ReminderReceiver` +3分钟使用可授权精确闹钟，未授权时保留非精确回退
- 勾选时可选申请 Android 精确闹钟权限；重启/更新后仅恢复预约，不假装立即启动
- 后台服务被系统拦截时发独立错误提示，明确未确认赛况
- 不提供100%不漏报承诺：系统权限、网络、API、关机/蓝牙仍可能造成漏报
