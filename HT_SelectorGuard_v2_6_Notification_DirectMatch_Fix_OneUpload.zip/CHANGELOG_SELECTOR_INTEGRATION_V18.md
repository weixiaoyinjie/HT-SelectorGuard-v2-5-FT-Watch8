# v1.8 一体化升级记录

- `app/src/main/assets/selector.html`：移植筛选 v1.7；新增 Bet365 0-0 正确比分赔率低于3 PASS，0-0模型>=30% PASS，模型>=25%并与主客近期0-0或小球市场共振 PASS，缺0-0报价降C；追加勾选即预警。
- `SelectorActivity.java` / `AIRequestBridge.java`：原筛选 WebView / PNG 和 AI 审计桥集成进手机包。
- `SelectorMonitorSync.java`：安卓侧二次校验 A/B、赔率与0-0风险；管理12场总配额、API key、开赛前预约、即时前台预警和取消勾选。
- `MainActivity.java` / `index.html`：原预警页加入“打开筛选引擎”入口、native选择结果与原观察名单自动同步，不改动通知内容。
- `wear/*`：通知实现不变，仅 versionCode/versionName 升级至配套版本，保留原圆形布局及向上滑动查看详情。
- `.github/workflows/build-apk.yml`：支持新 ZIP 与旧名兼容上传、运行新筛选单测和原 Watch8 单测、产出两个APK。
- 真实 APK 编译、设备安装、API 行为与后台启动需 GitHub Actions + 实机验证，当前没有提供伪造 APK。
