package com.htlive.watch44;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Framework-only Wear OS home screen. Does not load Google Play services at launch. */
public final class WatchHomeActivity extends Activity {
    private static final String TAG = "HTWatch8Start";
    private static final String PREF = "watch44_alerts";
    private static final String CHANNEL = "watch8_local_diagnostic_v1";
    private static final int PERMISSION_REQUEST = 302;
    private static final int DEMO_NOTIFICATION = 903302;
    private static final int AQUA = 0xff65e6d9;
    private TextView status;
    private boolean receiverRegistered;
    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { updateStatus(); }
    };

    private SharedPreferences prefs() { return getSharedPreferences(PREF, MODE_PRIVATE); }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        try {
            Log.i(TAG, "Watch8 diagnostic launcher onCreate; sdk="+Build.VERSION.SDK_INT);
            drawHome();
        } catch (Throwable error) {
            Log.e(TAG, "Failed to initialize home", error);
            try {
                TextView fallback = new TextView(this);
                fallback.setText("HT Watch8 启动检测\n界面初始化失败\n"+error.getClass().getSimpleName());
                fallback.setTextColor(Color.WHITE);
                fallback.setTextSize(15);
                fallback.setGravity(Gravity.CENTER);
                fallback.setBackgroundColor(Color.BLACK);
                setContentView(fallback);
            } catch (Throwable e) { Log.e(TAG,"Failed fallback",e); }
        }
    }

    @Override protected void onStart() {
        super.onStart();
        try {
            IntentFilter filter = new IntentFilter("com.htlive.watch44.STATUS_CHANGED");
            if (Build.VERSION.SDK_INT >= 33)
                registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(statusReceiver, filter);
            receiverRegistered = true;
        } catch (Throwable e) { Log.e(TAG,"Status receiver unavailable",e); }
        updateStatus();
    }
    @Override protected void onStop() {
        if (receiverRegistered) {
            try { unregisterReceiver(statusReceiver); } catch (Exception ignored) {}
            receiverRegistered = false;
        }
        super.onStop();
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] perms, int[] results) {
        super.onRequestPermissionsResult(requestCode, perms, results);
        if (requestCode == PERMISSION_REQUEST) {
            if (hasNotifyPermission()) sendLocalTest();
            else setStatus("通知权限未开启，首页仍可使用");
        }
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value); view.setTextColor(color);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        view.setGravity(Gravity.CENTER);
        if (bold) view.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return view;
    }
    private void addLine(LinearLayout layout, TextView line, int height, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(height));
        lp.bottomMargin=dp(bottom); layout.addView(line,lp);
    }
    private void addButton(LinearLayout layout, String caption, Runnable callback) {
        TextView button=text(caption,13,Color.WHITE,true);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xff183b41); bg.setCornerRadius(dp(22));
        bg.setStroke(dp(1),0xff4cb7ad);
        button.setBackground(bg);button.setClickable(true);button.setFocusable(true);
        button.setOnClickListener(v -> {
            try { callback.run(); }
            catch (Throwable ex) {
                Log.e(TAG,"Button failure: "+caption, ex);
                setStatus("操作失败："+ex.getClass().getSimpleName());
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(34));
        lp.leftMargin=dp(10); lp.rightMargin=dp(10); lp.bottomMargin=dp(5);
        layout.addView(button,lp);
    }
    private void drawHome() {
        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        LinearLayout layout=new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        int size=Math.min(getResources().getDisplayMetrics().widthPixels,
                          getResources().getDisplayMetrics().heightPixels);
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams((int)(size*0.82),-2,Gravity.CENTER);
        root.addView(layout,lp);
        setContentView(root);
        addLine(layout,text("HT WATCH 8",16,AQUA,true),27,0);
        addLine(layout,text("启动检测 · 首页已打开",13,Color.WHITE,true),24,4);
        status=text("本地界面启动正常",11,0xffd0e6ec,false);
        addLine(layout,status,25,3);
        addButton(layout,"测试本地通知",this::sendLocalTest);
        addButton(layout,"检测手机连接",this::checkPhone);
        addButton(layout,"查看同步赛况",this::openFullScreen);
        addLine(layout,text("本页不需要手机和足球 API",10,0xff8facb7,false),21,0);
    }
    private void setStatus(String message) {
        if (status != null) status.setText(message);
    }
    private void updateStatus() {
        if(status==null)return;
        try {
            SharedPreferences p=prefs();
            long t=p.getLong("phone_pong_at",0L);
            if(t>0 && System.currentTimeMillis()-t < 300000L) {
                setStatus("手机已响应 · 通信正常"); return;
            }
            String message=p.getString("connection_status",null);
            if(message!=null && !message.trim().isEmpty()) setStatus(message);
        } catch (Throwable ex) { Log.e(TAG,"Cannot refresh connection state",ex); }
    }
    private boolean hasNotifyPermission(){
        return Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;
    }
    private void sendLocalTest() {
        if (!hasNotifyPermission()) {
            setStatus("请允许手表通知权限");
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, PERMISSION_REQUEST);
            return;
        }
        NotificationManager manager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(manager==null) {setStatus("通知管理器不可用");return;}
        NotificationChannel channel=new NotificationChannel(CHANNEL,"Watch8 启动自检",NotificationManager.IMPORTANCE_HIGH);
        manager.createNotificationChannel(channel);
        Intent open=new Intent(this,WatchHomeActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,DEMO_NOTIFICATION,open,
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("HT Watch8 启动自检")
            .setContentText("本地通知测试成功（非真实比赛）")
            .setContentIntent(pi).setAutoCancel(true).build();
        manager.notify(DEMO_NOTIFICATION,n);
        setStatus("已发送本地测试通知");
    }
    private void checkPhone() {
        setStatus("开始检测手机连接…");
        // Keep Play Services loading outside this launcher Activity's startup path.
        WearConnectionProbe.ping(this, status);
    }
    private void openFullScreen() {
        startActivity(new Intent(this,WearAlertActivity.class));
    }
}
