package com.htlive.watch44;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.Wearable;
import com.google.android.gms.wearable.WearableListenerService;
import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataMapItem;
import org.json.JSONObject;
import org.json.JSONArray;
import java.nio.charset.StandardCharsets;

/** Accept phone alerts, show native watch notifications, and answer the entry-screen ping. */
public final class WearAlertListener extends WearableListenerService {
    static final String RISK="ht_44_risk_v1";
    static final String TIME="ht_44_time_v1";
    static final String PREF="watch44_alerts";
    static final String STATUS_CHANGED="com.htlive.watch44.STATUS_CHANGED";
    private static final int DEMO_NID=900001;

    @Override public void onMessageReceived(MessageEvent event) {
        try {
            String path=event.getPath();
            if ("/scorepath/pong".equals(path)) {
                String token=new String(event.getData(),StandardCharsets.UTF_8);
                SharedPreferences p=getSharedPreferences(PREF,Context.MODE_PRIVATE);
                if(!token.isEmpty() && token.equals(p.getString("pending_ping",""))){
                    p.edit().putLong("phone_pong_at",System.currentTimeMillis())
                        .putString("connection_status","手机已响应 · 连接正常")
                        .remove("pending_ping").apply();
                    changed(this);
                }
                return;
            }
            if ("/scorepath/snapshot".equals(path)) {
                saveSnapshot(new String(event.getData(),StandardCharsets.UTF_8));
                return;
            }
            if ("/scorepath/remove".equals(path)) {
                remove(new JSONObject(new String(event.getData(),StandardCharsets.UTF_8)));
                return;
            }
            if (!"/scorepath/alert".equals(path)) return;
            acceptAlert(new JSONObject(new String(event.getData(),StandardCharsets.UTF_8)),
                event.getSourceNodeId());
        } catch(Exception ex) { Log.e("HT44","Cannot process watch alert",ex); }
    }

    /** MessageClient and persistent DataClient converge on one idempotent posting path. */
    private void acceptAlert(JSONObject data,String sourceNodeId) throws Exception {
            int nid=data.optInt("nid",-1);
            long at=data.optLong("time",0);
            if(nid<0 || !data.has("fixture") || at<=0) return;
            long age=System.currentTimeMillis()-at;
            // Save delayed alerts to history, but never buzz for events older than 2 minutes.
            boolean historical=age>120_000L || age< -120_000L;
            SharedPreferences pref=getSharedPreferences(PREF,Context.MODE_PRIVATE);
            String token=data.optString("token","");
            if (!token.isEmpty() && token.equals(pref.getString("token_"+nid,"")) &&
                pref.getBoolean("posted_"+nid,false)) {
                received(sourceNodeId,token);
                return;
            }
            // Save even if the watch's notification permission is off. Never ACK a card
            // that was not actually displayed, so the phone can bridge as fallback.
            pref.edit().putString("alert_"+nid,data.toString())
                .putString("token_"+nid,token).putBoolean("posted_"+nid,false)
                .apply();
            if(at>=pref.getLong("latest_alert_at",0L)){
                pref.edit().putInt("latest",nid).putLong("latest_alert_at",at).apply();
            }
            changed(this);
            // Historical messages must not suppress native system mirroring.
            if(historical)return;
            if(!canNotify(this)) return;
            if (post(this,data,nid)) {
                pref.edit().putBoolean("posted_"+nid,true).apply();
                received(sourceNodeId,token);
            }
    }

    @Override public void onDataChanged(DataEventBuffer events){
        try{
            for(DataEvent event:events){
                String path=event.getDataItem().getUri().getPath();
                if(path==null)continue;
                if(path.startsWith("/scorepath/alert/")){
                    if(event.getType()==DataEvent.TYPE_DELETED){
                        String tail=path.substring("/scorepath/alert/".length());
                        try{eraseAlert(Integer.parseInt(tail));}
                        catch(NumberFormatException ignored){}
                    }else if(event.getType()==DataEvent.TYPE_CHANGED){
                        String json=DataMapItem.fromDataItem(event.getDataItem())
                            .getDataMap().getString("json");
                        if(json!=null)try{acceptAlert(new JSONObject(json),null);}
                        catch(Exception e){Log.w("HT44","Unable to read durable alert",e);}
                    }
                    continue;
                }
                if(event.getType()!=DataEvent.TYPE_CHANGED || !"/scorepath/live".equals(path))continue;
                String json=DataMapItem.fromDataItem(event.getDataItem()).getDataMap().getString("json");
                if(json!=null)saveSnapshot(json);
            }
        }catch(Exception e){Log.w("HT44","Data Layer snapshot unavailable",e);}
        finally{events.release();}
    }
    private void saveSnapshot(String json) throws org.json.JSONException {
        JSONObject snapshot=new JSONObject(json);
        long updated=snapshot.optLong("updatedAt",0L);
        long revision=snapshot.optLong("revisionAt",updated);
        SharedPreferences current=getSharedPreferences(PREF,Context.MODE_PRIVATE);
        if(revision>0 && revision>current.getLong("snapshot_revision_at",0L)){
            current.edit().putString("snapshot_json",snapshot.toString())
                .putLong("snapshot_at",updated)
                .putLong("snapshot_revision_at",revision)
                .putLong("snapshot_received_at",System.currentTimeMillis()).apply();
            changed(this);
        }
    }
    private static boolean canNotify(Context c){
        if(Build.VERSION.SDK_INT>=33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            return false;
        NotificationManager nm=(NotificationManager)c.getSystemService(NOTIFICATION_SERVICE);
        return nm!=null && nm.areNotificationsEnabled();
    }
    private static void changed(Context c){
        c.sendBroadcast(new Intent(STATUS_CHANGED).setPackage(c.getPackageName()));
    }
    private static boolean post(Context context,JSONObject j,int nid) {
        ensureChannels(context);
        Intent open=new Intent(context,WearAlertActivity.class);
        open.setAction("scorepath_open_"+nid);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        open.putExtra("nid",nid);
        PendingIntent pi=PendingIntent.getActivity(context,nid,open,
            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        boolean timed=j.optBoolean("timed",false);
        NotificationManager nm=(NotificationManager)context.getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel channel=nm.getNotificationChannel(timed?TIME:RISK);
        if(channel==null || channel.getImportance()==NotificationManager.IMPORTANCE_NONE) return false;
        // Native Wear OS cards are compact by design. The full original handset
        // title/body/detail remain stored in the alert JSON for swipe-up detail.
        WearBrief brief=WearBrief.from(j,System.currentTimeMillis());
        Notification notification=new Notification.Builder(context,timed?TIME:RISK)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(brief.nativeTitle())
            .setContentText(brief.nativePreview())
            .setStyle(new Notification.BigTextStyle().bigText(brief.nativeExpanded()))
            .setPriority(Notification.PRIORITY_HIGH)
            .setCategory(timed?Notification.CATEGORY_REMINDER:Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .setContentIntent(pi).setAutoCancel(true).setOngoing(false)
            .setOnlyAlertOnce(!j.optBoolean("fresh",true)).setShowWhen(false).build();
        nm.notify(nid,notification);
        return true;
    }
    /** Local end-to-end demonstration: no mobile connection or live game data involved. */
    public static void postDemo(Context context) throws Exception {
        if(!canNotify(context)) throw new SecurityException("通知权限未开启");
        JSONArray demonstrationPicks=new JSONArray()
            .put(new JSONObject().put("role","主单").put("pick","1-0").put("state","HIT"))
            .put(new JSONObject().put("role","保险1").put("pick","2-0").put("state","PENDING"))
            .put(new JSONObject().put("role","保险2").put("pick","1-1").put("state","PENDING"));
        JSONObject demo=new JSONObject().put("v",2).put("nid",DEMO_NID).put("fixture","")
            .put("kind","本地布局测试 · 非真实比赛").put("score","1-0")
            .put("teams","示例主队 vs 示例客队").put("minute",32)
            .put("sourceAt",System.currentTimeMillis()).put("statsFresh",false)
            .put("bets",demonstrationPicks).put("level","WATCH")
            .put("riskTitle","示例：主单命中中，下一球会改变比分")
            .put("riskAction","示例：核查平台结算报价")
            .put("phoneBody","布局测试，不是真实比赛。主单1-0、保险2-0与1-1。")
            .put("phoneDetail","仅用于检验一屏布局、下单比分颜色和向上滑动的完整详情。")
            .put("line1","测试手表圆形页面").put("line2","演示风险")
            .put("line3","不代表真实赛事建议")
            .put("timed",true).put("fresh",true);
        context.getSharedPreferences(PREF,MODE_PRIVATE).edit()
            .putString("alert_"+DEMO_NID,demo.toString()).apply();
        if (!post(context,demo,DEMO_NID))
            throw new IllegalStateException("手表通知频道已关闭");
    }
    private void received(String sourceNodeId,String token){
        if(token==null || token.isEmpty())return;
        byte[] bytes=token.getBytes(StandardCharsets.UTF_8);
        if(sourceNodeId!=null && !sourceNodeId.isEmpty()){
            Wearable.getMessageClient(this).sendMessage(sourceNodeId,"/scorepath/received",bytes);
        }else{
            // DataClient callbacks do not expose the originating node. ACK peers
            // explicitly so the phone can suppress duplicate notification bridging.
            Wearable.getNodeClient(this).getConnectedNodes().addOnSuccessListener(nodes->{
                for(com.google.android.gms.wearable.Node node:nodes)
                    Wearable.getMessageClient(this).sendMessage(node.getId(),"/scorepath/received",bytes);
            });
        }
    }
    private void eraseAlert(int nid){
        SharedPreferences prefs=getSharedPreferences(PREF,Context.MODE_PRIVATE);
        prefs.edit().remove("alert_"+nid).remove("token_"+nid).remove("posted_"+nid).apply();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(nid);
        if(prefs.getInt("latest",-1)==nid)prefs.edit().remove("latest").remove("latest_alert_at").apply();
        changed(this);
    }
    private static void ensureChannels(Context context) {
        NotificationManager nm=(NotificationManager)context.getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel risk=new NotificationChannel(RISK,"重要比分与守分预警",NotificationManager.IMPORTANCE_HIGH);
        risk.enableVibration(true);risk.setVibrationPattern(new long[]{0,220,120,220});
        NotificationChannel checkpoint=new NotificationChannel(TIME,"开赛与15/30/40分钟",NotificationManager.IMPORTANCE_HIGH);
        checkpoint.enableVibration(true);checkpoint.setVibrationPattern(new long[]{0,170});
        nm.createNotificationChannel(risk);nm.createNotificationChannel(checkpoint);
    }
    private void remove(JSONObject data) {
        JSONArray ids=data.optJSONArray("ids");if(ids==null)return;
        SharedPreferences pref=getSharedPreferences(PREF,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=pref.edit();
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        for(String key:pref.getAll().keySet()) {
            if(!key.startsWith("alert_"))continue;
            try {
                JSONObject notice=new JSONObject(pref.getString(key,"{}"));
                for(int i=0;i<ids.length();i++) if(ids.optString(i).equals(notice.optString("fixture"))) {
                    int nid=notice.optInt("nid",-1);
                    if(nid>=0){
                        nm.cancel(nid);
                        editor.remove("alert_"+nid).remove("token_"+nid).remove("posted_"+nid);
                        if(pref.getInt("latest",-1)==nid) editor.putInt("latest",-1);
                    }
                    break;
                }
            }catch(Exception ignored){}
        }
        editor.apply();changed(this);
    }
}
