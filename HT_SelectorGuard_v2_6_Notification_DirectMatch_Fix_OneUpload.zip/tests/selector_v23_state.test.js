'use strict';
const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const html=fs.readFileSync('app/src/main/assets/selector.html','utf8');
const script=html.split('<script>')[1].split('</script>')[0];
assert(script.includes('switchPeriod(lastPeriod(),true)'));
const mockStorage=new Map(),selection=new Map(),saved=new Map();
function runPage(){
 const els=new Map();
 const local={getItem:k=>mockStorage.get(k)??null,setItem:(k,v)=>mockStorage.set(k,String(v)),removeItem:k=>mockStorage.delete(k)};
 function element(id){
  if(!els.has(id))els.set(id,{id,textContent:'',innerHTML:'',value:id==='minOdd'?'4':id==='day'?'2026-11-22':id==='sortMode'?'original':'',checked:id==='skipRisk',disabled:false,style:{},
   classList:{toggle(){},contains(){return false},add(){},remove(){}},
   addEventListener(){},setAttribute(){},querySelectorAll(){return []},focus(){}});
  return els.get(id);
 }
 const android={
  getKey:()=>'',selectedMatches:()=>JSON.stringify([...selection.values()]),
  setSelected:(raw,checked)=>{const x=JSON.parse(raw);if(checked){selection.set(x.id,x)}else selection.delete(x.id);return JSON.stringify({ok:true,status:checked?'ARMED':'UPDATED',message:'已同步'})},
  saveSnapshot:(mode,json)=>{saved.set(mode,json);return 'OK'},loadSnapshot:mode=>saved.get(mode)||'',
  setPageMode:mode=>mockStorage.set('currentMode',mode),lastPageMode:()=>mockStorage.get('currentMode')||'HT',
  openMonitor(){}
 };
 const doc={getElementById:element,addEventListener(){},hidden:false};
 const ctx={document:doc,localStorage:local,AndroidMonitor:android,console,Intl,Date,Math,Map,Set,
  Number,JSON,Object,Array,Error,RegExp,String,Boolean,parseFloat,parseInt,
  setTimeout(fn){fn();return 0},URLSearchParams,Blob,TextEncoder};
 ctx.window=ctx;ctx.globalThis=ctx;
 const code=script.replace(/\}\)\(\);\s*$/,`globalThis.__test={app,switchPeriod,saveSelectorSnapshot,restoreSelectorSnapshot,toggleCandidate,renderResults};})();`);
 vm.runInNewContext(code,ctx,{timeout:3000});
 return {ctx,els,get:()=>ctx.__test};
}
const fixture={fixture:{id:7654321,date:'2026-12-01T18:00:00+00:00'},league:{id:33,season:2026,name:'Test League'},teams:{home:{id:1,name:'Home'},away:{id:2,name:'Away'}}};
const ft={f:fixture,period:'FT',main:{score:'1-0',mode:{scores:['1-0','2-0','1-1']}},verdict:{grade:'B'},
 zeroRisk:{p00:.12,severe:false},analysis:{grade:'B',canSelect:true,fit:{p00:.12,p4:.18,homeWin:.67},reason:'结构匹配',
 combo:{main:'1-0',scores:['1-0','2-0','1-1'],items:[
 {score:'1-0',odd:5,probability:.28},{score:'2-0',odd:8,probability:.14},{score:'1-1',odd:6,probability:.2}],allPriced:true,coverage:.62},home:{siteN:12},away:{siteN:12}}};
const p1=runPage();
p1.get().switchPeriod('FT');
p1.get().app.ranked=[ft];
assert.equal(p1.get().saveSelectorSnapshot(true),true,'FT scan can be cached');
assert(saved.has('FT'));
p1.get().toggleCandidate('7654321:1-0',true);
assert(selection.has('7654321'),'one tap arms native monitoring');
assert(p1.els.get('results').innerHTML.includes('✓ 已加入 · 取消'));
assert(!saved.get('FT').includes('sk-test-secret'),'snapshot holds no AI credentials');
p1.get().switchPeriod('HT');
assert.equal(p1.get().app.ranked.length,0);
p1.get().switchPeriod('FT');
assert.equal(p1.get().app.ranked.length,1,'FT candidates survive HT/FT switching');
assert.equal(p1.get().app.selected.size,1,'checked state reconciled with native watchlist');
// Cold app restart and independent HT/FT caches.
const p2=runPage();
assert.equal(p2.get().app.period,'FT','last-used period reopens');
assert.equal(p2.get().app.ranked.length,1,'FT candidates survive WebView destruction/restart');
assert.equal(p2.get().app.selected.size,1);
p2.get().toggleCandidate('7654321:1-0',false);
assert.equal(selection.has('7654321'),false,'direct toggle can remove an alert');
assert.equal(p2.get().app.selected.size,0,'native and UI selection agree');
assert(p2.els.get('results').innerHTML.includes('🔔 直接加入预警'));
console.log('PASS: independent HT/FT snapshots, cold start restoration, confirmed direct monitoring toggle and native selection reconciliation');
