'use strict';
const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const html=fs.readFileSync('app/src/main/assets/selector.html','utf8');
const script=html.split('<script>')[1].split('</script>')[0];
const syncSource=fs.readFileSync('app/src/main/java/com/htlive/monitor/SelectorMonitorSync.java','utf8');
new vm.Script(script);
const selected=new Map(),snapshots=new Map(),elements=new Map();
function el(id){if(!elements.has(id))elements.set(id,{value:id==='minOdd'?'4':id==='day'?'2026-11-22':'',innerHTML:'',textContent:'',checked:false,disabled:false,style:{},classList:{toggle(){},contains(){return false},add(){},remove(){}},addEventListener(){},setAttribute(){},querySelectorAll(){return []},focus(){}});return elements.get(id)}
const monitor={getKey:()=>'',selectedMatches:()=>JSON.stringify([...selected.values()]),
 setSelected:(raw,checked)=>{const x=JSON.parse(raw);if(checked)selected.set(x.id,x);else selected.delete(x.id);return JSON.stringify({ok:true,message:'已加入人工观察预警'})},
 saveSnapshot:(mode,raw)=>{snapshots.set(mode,raw);return 'OK'},loadSnapshot:mode=>snapshots.get(mode)||'',
 setPageMode(){},lastPageMode:()=> 'FT',openMonitor(){}
};
const local={getItem(){return null},setItem(){},removeItem(){}};
const context={document:{getElementById:el,addEventListener(){},hidden:false},localStorage:local,AndroidMonitor:monitor,console,Intl,Date,Math,Map,Set,Number,JSON,Object,Array,Error,RegExp,String,Boolean,parseFloat,parseInt,URLSearchParams,Blob,TextEncoder,setTimeout(fn){fn();return 0}};
context.window=context;context.globalThis=context;
vm.runInNewContext(script.replace(/\}\)\(\);\s*$/,`globalThis.T={app,switchPeriod,renderResults,toggleCandidate,nativeMonitorToggle,updateSelectionFromNative};})();`),context,{timeout:5000});
const {app,switchPeriod,renderResults,toggleCandidate,nativeMonitorToggle,updateSelectionFromNative}=context.T;
const fixture=id=>({fixture:{id,date:'2026-12-01T18:00:00+00:00'},league:{name:'League',id:1},teams:{home:{id:11,name:'Home'},away:{id:22,name:'Away'}}});
function match(id,grade,analysis={}){
 return {f:fixture(id),period:'FT',main:{score:'1-0',mode:{scores:[]}},verdict:{grade},
 zeroRisk:{severe:grade==='PASS',p00:.5},analysis:{grade,canSelect:false,reason:'赔率不齐或风险高',...analysis}};
}
switchPeriod('FT');
const c=match(7000001,'C');
const pass=match(7000002,'PASS');
app.ranked=[c,pass];renderResults();
const cards=el('results').innerHTML;
assert(cards.includes('勾选加入全场观察预警（非下注建议）'));
assert(!cards.includes('PASS/C 不允许勾选'));
assert(!cards.includes('data-select="7000001:1-0" disabled'));
assert(!cards.includes('data-select="7000002:1-0" disabled'));
toggleCandidate('7000001:1-0',true);
toggleCandidate('7000002:1-0',true);
assert.equal(selected.size,2,'C and PASS both reach native monitoring');
for(const id of ['7000001','7000002']){
 const payload=selected.get(id);
 assert.equal(payload.observeOnly,true);
 assert.equal(payload.suggestedScores.length,0,'no invented score combinations');
 assert.equal(payload.main,'','no implied bet for observation only');
 assert.equal(payload.period,'FT');
}
assert.equal(selected.get('7000002').grade,'PASS','grade stays PASS');
assert.equal(snapshots.has('FT'),true,'candidate cache remains enabled');
updateSelectionFromNative();
assert.equal(app.selected.size,2,'C/PASS stay checked on monitor return');
toggleCandidate('7000002:1-0',false);
assert.equal(selected.has('7000002'),false,'manual alert can be removed');
const ht={f:fixture(7000003),period:'HT',main:{score:'1-0',mode:{scores:['1-0','0-0']}},verdict:{grade:'PASS'},zeroRisk:{severe:true,price:2.4,p00:.40}};
nativeMonitorToggle(ht,true);
assert.equal(selected.get('7000003').observeOnly,true,'high 0-0 risk is monitored despite PASS');
assert.equal(selected.get('7000003').period,'HT');
const ab={...ht,f:fixture(7000004),verdict:{grade:'B'}};
assert.throws(()=>nativeMonitorToggle(ab,true),/0-0/,'existing A/B strict gate remains');
assert(syncSource.includes('boolean observeOnly="C".equals(grade)||"PASS".equals(grade);'));
assert(syncSource.includes('if(!observeOnly && "HT".equals(period))'));
assert(syncSource.includes('}else if(!observeOnly){'));
assert(syncSource.includes('.put("suggestedScores",observeOnly?new JSONArray():'));
assert(syncSource.includes('if(kickoff<System.currentTimeMillis()-'));
assert(syncSource.includes('if(merged.size()>12)'));
console.log('PASS: C/PASS FT and HT selectable, no betting score fabricated, A/B unchanged, original native limits preserved');
