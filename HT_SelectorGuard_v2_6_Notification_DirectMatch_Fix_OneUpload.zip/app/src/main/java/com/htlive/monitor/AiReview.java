package com.htlive.monitor;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Optional second opinion; never predicts a numerical goal probability or triggers alone. */
public final class AiReview {
    private AiReview(){}
    static JSONObject review(JSONObject match,String apiKey) throws Exception {
        if(apiKey==null||apiKey.isEmpty())throw new Exception("未设置AI Key");
        JSONObject slim=new JSONObject();
        for(String s:new String[]{"id","status","minute","h","a","trend","newRed","lastRedAt","mainPick","guardLastGoalAt","lastStatsAt"})
            if(match.has(s))slim.put(s,match.get(s));
        for(String s:new String[]{"stats","delta","goalWarning","mainPickRisk","guardRisk"})
            if(match.has(s))slim.put(s,match.get(s));
        // Monetary amounts and platform settlement quotes stay on-device.
        JSONArray safeBets=new JSONArray(),original=match.optJSONArray("guardBets");
        if(original!=null)for(int i=0;i<Math.min(original.length(),3);i++){
            JSONObject bet=original.optJSONObject(i);if(bet==null)continue;
            safeBets.put(new JSONObject().put("role",bet.optString("role",""))
                .put("pick",bet.optString("pick",""))
                .put("closed",bet.optBoolean("closed",false)));
        }
        slim.put("guardBets",safeBets);
        JSONObject req=new JSONObject();
        req.put("model","gpt-4.1-mini");req.put("max_output_tokens",450);
        req.put("instructions","你是上半场【正确比分路径、守分、人工提前结算】证据复核器。第一判断：逐张主单/保险单能否到达目标（当前比分是否超过目标、要主队/客队再进几球、所需进球方的真实短窗进攻质量）。第二：一张或多张比分命中后，主客下一球分别会破坏哪张单，或由哪张保险单承接；参考guardRisk.nextHome/nextAway，注意两球及更多进球的其他风险。第三：命中比分后能否维持到半场：必须用当前比分阶段独立3/5/10分钟增量、射正、禁区进攻、如有xG、红牌，时间只作为实现与暴露窗口的次要变量。goalWarning和guardRisk来自同一个足球数据API与本地规则，AI只是逻辑复核，不是第二个独立事实源；没有真实短窗则承认数据不足。不得把进球前总计统计当进球后趋势；不得武断说刚进球必然持续压制。不可虚构进球概率、下注赔率和平台结算金额；结算是否划算须用户手动填写平台报价，平台可能暂停。只返回JSON五个字符串reach、hold、risk、confidence、action。confidence只能‘数据支持’或‘数据不足’，action只能‘核查结算报价’、‘继续观察’、‘数据不足’；输出要简短、简体中文，每项90字以内。不自动投注、不自动结算。");
        req.put("input","请二次核对API-FOOTBALL半场快照（未知为null）："+slim.toString());
        req.put("text",new JSONObject().put("format",new JSONObject().put("type","json_object")));
        HttpURLConnection con=(HttpURLConnection)new URL("https://api.openai.com/v1/responses").openConnection();
        try{
            con.setRequestMethod("POST");con.setDoOutput(true);
            con.setConnectTimeout(6500);con.setReadTimeout(9000);
            con.setRequestProperty("Authorization","Bearer "+apiKey);
            con.setRequestProperty("Content-Type","application/json; charset=utf-8");
            try(OutputStream out=con.getOutputStream()){out.write(req.toString().getBytes(StandardCharsets.UTF_8));}
            int status=con.getResponseCode();
            if(status<200||status>=300)throw new Exception("OpenAI HTTP "+status);
            byte[] buf=new byte[4096];int n;ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            try(InputStream in=con.getInputStream()){
                while((n=in.read(buf))!=-1){bytes.write(buf,0,n);if(bytes.size()>250_000)throw new Exception("AI响应超过限制");}
            }
            JSONObject root=new JSONObject(bytes.toString("UTF-8"));
            JSONArray output=root.optJSONArray("output");String text="";
            if(output!=null)for(int i=0;i<output.length();i++){
                JSONObject item=output.optJSONObject(i);if(item==null)continue;
                JSONArray contents=item.optJSONArray("content");if(contents==null)continue;
                for(int k=0;k<contents.length();k++){
                    JSONObject block=contents.optJSONObject(k);
                    if(block!=null&&"output_text".equals(block.optString("type"))){text=block.optString("text");break;}
                }
                if(!text.isEmpty())break;
            }
            JSONObject result=new JSONObject(text);
            return new JSONObject().put("reach",truncate(result.optString("reach","数据不足"),130))
              .put("hold",truncate(result.optString("hold","数据不足"),130))
              .put("conclusion",truncate(result.optString("conclusion",result.optString("hold","AI未给出结论")),130))
              .put("risk",truncate(result.optString("risk",""),120))
              .put("confidence",truncate(result.optString("confidence","数据不足"),16))
              .put("action",parseAction(result.optString("action","继续观察")))
              .put("time",System.currentTimeMillis());
        }finally{con.disconnect();}
    }
    private static String parseAction(String value){
        if("核查结算报价".equals(value)||"复核结算报价".equals(value)||"继续观察".equals(value)||"数据不足".equals(value))return value;
        return "数据不足";
    }
    private static String truncate(String s,int size){return s.length()>size?s.substring(0,size):s;}
}
