package com.htlive.monitor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Restore saved match alarms after a reboot / package upgrade.
 * Boot receivers never start foreground dataSync services on Android 15+;
 * they only schedule future alarms. */
public final class BootRescheduleReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){
        if(intent==null)return;
        String action=intent.getAction();
        if(!Intent.ACTION_BOOT_COMPLETED.equals(action) &&
           !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action))return;
        SharedPreferences p=context.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
        String pending=p.getString("alarm_watch","[]");
        // The process/service is no longer alive even if a stale persisted flag says otherwise.
        p.edit().putBoolean("running",false).apply();
        ReminderReceiver.schedule(context,pending);
    }
}
