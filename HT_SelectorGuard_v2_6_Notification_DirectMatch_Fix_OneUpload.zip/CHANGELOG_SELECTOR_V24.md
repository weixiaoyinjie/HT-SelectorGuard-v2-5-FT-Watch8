# v2.4 · C级/PASS 手动加入预警观察

基于 v2.3 的完整源码，定向开放手动预警观察，**不改变半场和全场筛选评级算法，也不改变后台计时、实际比赛 API、推送和 Watch8 通知实现**。

- 半场/全场结果里的 A/B/C/PASS 均有可用勾选框、直接加入/取消预警按钮。C和PASS的评级、0-0风险、赔率缺失警示等均不消失。
- C/PASS被选择时通过原有 Android 预警名单桥接添加比赛 ID，标记 `observeOnly=true`，且 `suggestedScores=[]`、`main=''`。这表示只监测赛况，**不凭被否决的模型建议自动填写任何下注比分**。用户可以在预警页自行填写并保存实际比分单。
- 安卓端 `SelectorMonitorSync.validate` 对 C/PASS 开放原生观察资格，不再因0-0硬排除、赔率缺失、全场三张预设不齐拒绝添加，仍坚持比赛 ID、队名、开赛时间有效。原有 A/B 严格校验保持不变。
- 筛选缓存、半场/全场模式锁定、12场上限、API Key、开赛第3分钟前不通知、超时/已结束拒绝、既有通知逻辑均保留。
- “勾选前10场”仍只批量选择 A/B，C/PASS需用户逐场自行决定，避免把 PASS 批量加入。
- 预警页通过原生名单同步评级，C/PASS显示“⚠ 人工观察”，不会误以为A级候选。
- versionCode 15（较 v2.3 的14递增），同 applicationId 与开发签名，用于手机升级安装；手表包没有变化。

## 构建与检验

`node tests/selector_v24_observation.test.js` 检查全场C/PASS报价不齐时仍能勾选、原生桥接观察标记、名单持久化、HT PASS校验绕行、A/B保持原有赔率要求，回归 `tests/*.test.js`、`tests/selector/*.js` 等。Android正式编译需要使用随源码附带的 GitHub Actions；本地环境未安装 Android SDK 时不会声称已直接生成新的 APK。
