# v3.5 更改日志
- 手机比赛统计与手表比赛列表同源：每次 MonitorService.pollOnce 成功后推送；手表打开时可主动请求缓存快照。
- 原有警报瞬时发送逻辑保留；增加完整通知正文/详情同步、展开显示与时间戳。
- 消息渠道使用 NodeClient 减少 capability 检索失败，同时将最近赛况通过 DataClient 持久同步；超过2分钟的延迟通知仅存历史，不作为实时提醒震动。
- 截图：安卓 Uri 直接 OCR 原图，网页只保存900px缩略图，降低多图上传本地存储占用；保持现有 ID/队名/开球日期核验。
- Android app / wear versionCode 均提高到6；保持相同包名与开发测试签名。
- 新增回归测试 watch8_sync_ocr_v35.test.js 与扩展全量 payload 测试。
